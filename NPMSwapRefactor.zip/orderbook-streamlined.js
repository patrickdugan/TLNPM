const StreamlinedSwapper = require('./streamlined-swapper.js');
const BigNumber = require('bignumber.js');
const util = require('util');

/**
 * OrderbookSession - Handles orderbook events and trade execution
 * Uses StreamlinedSwapper for 2-3 RT trades
 */
class OrderbookSession {
    constructor(socket, myInfo, client, test) {
        console.log('Initializing orderbook session:', JSON.stringify(myInfo));
        this.socket = socket;
        this.myInfo = myInfo;
        this.client = client;
        this.test = test;
        this.activeSwaps = new Map();
        
        this.startSession();
    }

    setInfo(myInfo) {
        this.myInfo = myInfo;
    }

    startSession() {
        this.socket.on('connection', () => {
            console.log('Connected to orderbook server.');
            this.subscribeToOrderbook();
        });

        this.socket.on('disconnect', () => {
            console.log('Disconnected from orderbook server.');
        });

        this.handleOrderMatches();
        this.handleNewOrders();
        this.handleOrderUpdates();
        this.handleClosedOrders();
    }

    subscribeToOrderbook() {
        this.socket.emit('subscribe', { event: 'update-orderbook', assets: ['LTC', 'BTC'] });
        console.log('Subscribed to orderbook.');

        this.socket.on('update-orderbook', (data) => {
            console.log('Orderbook updated:', data);
        });
    }

    handleNewOrders() {
        this.socket.on('new-order', (data) => {
            console.log('New order:', data);
        });

        this.socket.on('many-orders', (data) => {
            console.log('Bulk orders:', data);
        });
    }

    handleOrderUpdates() {
        this.socket.on('update-orderbook', (data) => {
            console.log('Orderbook update:', data);
        });
    }

    handleClosedOrders() {
        this.socket.on('close-order', (orderUUID) => {
            console.log(`Order ${orderUUID} closed.`);
        });
    }

    /**
     * Handle matched orders - initiate streamlined swap
     */
    handleOrderMatches() {
        this.socket.on('new-channel', async (swapConfig) => {
            const tradeInfo = swapConfig?.tradeInfo;
            console.log('New channel match:', JSON.stringify(swapConfig));

            if (!tradeInfo?.buyer || !tradeInfo?.seller) {
                console.log('Invalid trade info, skipping');
                return;
            }

            try {
                // Ensure we have our address
                if (!this.myInfo.keypair?.address) {
                    await this.getUTXOBalances();
                    if (!this.myInfo.keypair?.address) {
                        console.log('No address available');
                        return;
                    }
                }

                const { buyer, seller } = tradeInfo;
                const myAddress = this.myInfo.keypair.address;

                // Determine if we're buyer or seller
                let isBuyer;
                if (myAddress === buyer.keypair.address) {
                    isBuyer = true;
                    console.log('I am the BUYER');
                } else if (myAddress === seller.keypair.address) {
                    isBuyer = false;
                    console.log('I am the SELLER');
                } else {
                    console.log('Address mismatch - not my trade');
                    return;
                }

                // Generate trade UUID
                const tradeUUID = `${buyer.uuid || 'b'}-${seller.uuid || 's'}-${Date.now()}`;

                // Check for duplicate
                if (this.activeSwaps.has(tradeUUID)) {
                    console.log('Duplicate swap, skipping');
                    return;
                }

                // Create streamlined swapper
                const myInfo = isBuyer ? buyer : seller;
                const cpInfo = isBuyer ? seller : buyer;

                const swapper = new StreamlinedSwapper(
                    tradeInfo,
                    myInfo,
                    cpInfo,
                    isBuyer,
                    this.client,
                    this.socket,
                    this.test,
                    tradeUUID
                );

                this.activeSwaps.set(tradeUUID, swapper);

                // Execute swap
                const result = await swapper.onReady();

                // Cleanup
                this.activeSwaps.delete(tradeUUID);

                if (result.error) {
                    console.error(`Swap failed: ${result.error}`);
                } else {
                    console.log(`Swap complete: ${result.data?.txid}`);
                }

            } catch (error) {
                console.error('Error handling match:', error);
            }
        });
    }

    async getUTXOBalances(address) {
        try {
            const utxos = await this.listUnspent();
            let totalBalance = new BigNumber(0);

            for (const utxo of utxos) {
                if (utxo.address === address) {
                    totalBalance = totalBalance.plus(utxo.amount);
                } else if (!this.myInfo.keypair?.address) {
                    this.myInfo.keypair.address = utxo.address;
                    this.myInfo.keypair.pubkey = await this.getPubKeyFromAddress(utxo.address);
                    totalBalance = totalBalance.plus(utxo.amount);
                } else if (address === '' && this.myInfo.keypair.address) {
                    const pubkey = await this.getPubKeyFromAddress(utxo.address);
                    this.myInfo.otherAddrs.push({ address: utxo.address, pubkey });
                    totalBalance = totalBalance.plus(utxo.amount);
                }
            }

            console.log(`Total balance: ${totalBalance.toString()}`);
            return this.myInfo.keypair?.address;
        } catch (error) {
            console.error('Error fetching balances:', error);
        }
    }

    listUnspent(...params) {
        return util.promisify(this.client.cmd.bind(this.client, 'listunspent'))(...params);
    }

    async getPubKeyFromAddress(address) {
        try {
            const getAddressInfo = util.promisify(this.client.cmd.bind(this.client, 'getaddressinfo'));
            const info = await getAddressInfo(address);
            return info?.pubkey;
        } catch (error) {
            console.error('Error getting pubkey:', error);
        }
    }

    /**
     * Cancel an active swap
     */
    cancelSwap(tradeUUID) {
        const swapper = this.activeSwaps.get(tradeUUID);
        if (swapper) {
            swapper.terminate('Cancelled by user');
            this.activeSwaps.delete(tradeUUID);
        }
    }

    /**
     * Get active swap count
     */
    getActiveSwapCount() {
        return this.activeSwaps.size;
    }
}

module.exports = OrderbookSession;
