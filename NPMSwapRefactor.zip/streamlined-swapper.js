const Encode = require('./tradelayer.js/src/txEncoder.js');
const WalletListener = require('./tradelayer.js/src/walletInterface.js');
const { buildSignAndBroadcastCommitTx, buildFuturesTransaction, buildTokenTradeTransaction, signPsbtRawTx } = require('./litecoreTxBuilder');
const util = require('util');
const BigNumber = require('bignumber.js');

/**
 * StreamlinedSwapper - 2-3 Round Trip Swap Protocol
 * 
 * FLOW:
 *   STEP 1 (Seller initiates):
 *     - Create/verify multisig
 *     - Build + send funding tx (commit)
 *     - Build trade PSBT
 *     - If taker: sign PSBT
 *     - Emit to buyer
 * 
 *   STEP 2 (Buyer responds):
 *     - Verify multisig
 *     - RBF check on seller's commit
 *     - Build + send own funding tx
 *     - Sign PSBT
 *     - If seller was taker: finalize + broadcast, done
 *     - If seller was maker: emit back for final sig
 * 
 *   STEP 3 (Only if seller is maker):
 *     - RBF check on buyer's commit
 *     - Sign + finalize + broadcast
 */

class StreamlinedSwapper {
    constructor(tradeInfo, myInfo, cpInfo, isBuyer, client, socket, test, tradeUUID) {
        this.tradeInfo = tradeInfo;
        this.myInfo = myInfo;
        this.cpInfo = cpInfo;
        this.isBuyer = isBuyer;
        this.client = client;
        this.socket = socket;
        this.test = test;
        this.tradeUUID = tradeUUID;
        this.multySigChannelData = null;
        this.tradeStartTime = Date.now();

        // Promisify RPC methods
        this.getRawTransactionAsync = util.promisify(client.getRawTransaction.bind(client));
        this.createRawTransactionAsync = util.promisify(client.createRawTransaction.bind(client));
        this.listUnspentAsync = util.promisify(client.cmd.bind(client, 'listunspent'));
        this.decoderawtransactionAsync = util.promisify(client.cmd.bind(client, 'decoderawtransaction'));
        this.dumpprivkeyAsync = util.promisify(client.cmd.bind(client, 'dumpprivkey'));
        this.sendrawtransactionAsync = util.promisify(client.cmd.bind(client, 'sendrawtransaction'));
        this.getBlockCountAsync = util.promisify(client.cmd.bind(client, 'getblockcount'));
        this.addMultisigAddressAsync = util.promisify(client.cmd.bind(client, 'addmultisigaddress'));
        this.validateAddressAsync = util.promisify(client.cmd.bind(client, 'validateaddress'));
        this.signrawtransactionwithkeyAsync = util.promisify(client.cmd.bind(client, 'signrawtransactionwithkey'));
        this.getChannelAsync = util.promisify(client.cmd.bind(client, 'tl_getchannel'));

        this.setupEventHandlers();
    }

    get isMaker() {
        // sellerIsMaker from trade props tells us if seller posted the order
        const props = this.tradeInfo.props || this.tradeInfo;
        const sellerIsMaker = props.sellerIsMaker ?? false;
        // If I'm buyer: I'm maker if seller is NOT maker
        // If I'm seller: I'm maker if seller IS maker
        return this.isBuyer ? !sellerIsMaker : sellerIsMaker;
    }

    get isInitiator() {
        // Seller always initiates (has what buyer wants)
        return !this.isBuyer;
    }

    get network() {
        return this.test ? 'LTCTEST' : 'LTC';
    }

    logTime(stage) {
        console.log(`[Swap:${this.tradeUUID?.slice(0,8)}] ${stage}: ${Date.now() - this.tradeStartTime}ms`);
    }

    onReady() {
        return new Promise((resolve, reject) => {
            this.readyRes = resolve;
            this.readyRej = reject;
            setTimeout(() => this.terminate('Timeout'), 90000);
            
            // Seller initiates
            if (this.isInitiator) {
                this.initiateStep1();
            }
        });
    }

    cleanup() {
        this.socket.off(`${this.cpInfo.socketId}::swap`);
    }

    terminate(reason) {
        this.logTime(`TERMINATED: ${reason}`);
        this.socket.emit(`${this.myInfo.socketId}::swap`, {
            eventName: 'TERMINATE',
            socketId: this.myInfo.socketId,
            data: { reason, tradeUUID: this.tradeUUID }
        });
        this.cleanup();
        this.readyRes?.({ error: reason });
    }

    complete(txid) {
        this.logTime(`COMPLETE: ${txid}`);
        this.cleanup();
        this.readyRes?.({ data: { txid } });
    }

    setupEventHandlers() {
        const eventName = `${this.cpInfo.socketId}::swap`;
        this.socket.on(eventName, async (event) => {
            if (event.data?.tradeUUID && event.data.tradeUUID !== this.tradeUUID) return;

            try {
                switch (event.eventName) {
                    case 'STEP1':
                        await this.handleStep1(event.data);
                        break;
                    case 'STEP2':
                        await this.handleStep2(event.data);
                        break;
                    case 'COMPLETE':
                        this.complete(event.data.txid);
                        break;
                    case 'TERMINATE':
                        this.cleanup();
                        this.readyRes?.({ error: event.data?.reason || 'Terminated by peer' });
                        break;
                }
            } catch (err) {
                this.terminate(`Event error: ${err.message}`);
            }
        });
    }

    // ==================== STEP 1: SELLER INITIATES ====================

    async initiateStep1() {
        this.logTime('STEP1: Initiating');
        try {
            // 1. Create multisig
            const pubKeys = this.getPubkeyOrder();
            const msRes = await this.addMultisigAddressAsync(2, pubKeys);
            if (!msRes?.address) throw new Error('Failed to create multisig');

            const validateRes = await this.validateAddressAsync(msRes.address);
            this.multySigChannelData = {
                address: msRes.address,
                redeemScript: msRes.redeemScript,
                scriptPubKey: validateRes?.scriptPubKey
            };

            // 2. Get column assignment
            const columnInfo = await this.getColumnInfo();
            
            // 3. Get block height for expiry
            const blockHeight = await this.getBlockCountAsync();
            const expiryBlock = blockHeight + 10;

            // 4. Build and send commit tx
            const commitResult = await this.buildAndSendCommit(columnInfo);
            
            // 5. Build trade PSBT
            const psbtResult = await this.buildTradePsbt(commitResult.utxo, expiryBlock, columnInfo);

            // 6. If taker, sign now
            let psbtHex = psbtResult.psbtHex;
            let isSigned = false;
            
            if (!this.isMaker) {
                const wif = await this.dumpprivkeyAsync(this.myInfo.keypair.address);
                const signRes = await signPsbtRawTx({ wif, network: this.network, psbtHex }, this.client);
                if (signRes?.data?.psbtHex) {
                    psbtHex = signRes.data.psbtHex;
                    isSigned = true;
                }
            }

            // 7. Emit to buyer
            this.socket.emit(`${this.myInfo.socketId}::swap`, {
                eventName: 'STEP1',
                socketId: this.myInfo.socketId,
                data: {
                    tradeUUID: this.tradeUUID,
                    multisig: this.multySigChannelData,
                    commitTxId: commitResult.txid,
                    commitUtxo: commitResult.utxo,
                    psbtHex,
                    isSigned,
                    isMaker: this.isMaker,
                    columnInfo
                }
            });

            this.logTime('STEP1: Complete');
        } catch (err) {
            this.terminate(`Step1: ${err.message}`);
        }
    }

    // ==================== STEP 2: BUYER RESPONDS ====================

    async handleStep1(data) {
        if (this.isBuyer) {
            await this.buyerStep2(data);
        }
    }

    async buyerStep2(data) {
        this.logTime('STEP2: Processing');
        try {
            const { multisig, commitTxId, psbtHex, isSigned, isMaker, columnInfo } = data;

            // 1. Verify multisig
            const pubKeys = this.getPubkeyOrder();
            const msRes = await this.addMultisigAddressAsync(2, pubKeys);
            if (msRes.redeemScript !== multisig.redeemScript) {
                throw new Error('Multisig mismatch');
            }
            this.multySigChannelData = multisig;

            // 2. RBF check on seller's commit
            if (commitTxId) {
                await this.checkRbf(commitTxId);
            }

            // 3. Get block height
            const blockHeight = await this.getBlockCountAsync();
            const expiryBlock = blockHeight + 10;

            // 4. Build and send our commit
            const myColumnInfo = await this.getColumnInfo();
            const commitResult = await this.buildAndSendCommit(myColumnInfo);

            // 5. Sign the PSBT
            const wif = await this.dumpprivkeyAsync(this.myInfo.keypair.address);
            let signRes = await signPsbtRawTx({ wif, network: this.network, psbtHex }, this.client);
            
            if (!signRes?.data?.psbtHex) {
                throw new Error('Failed to sign PSBT');
            }

            // 6. If seller already signed (taker), we can finalize
            if (isSigned) {
                // Finalize and broadcast
                const finalHex = signRes.data.finalHex;
                if (!finalHex) {
                    throw new Error('Failed to finalize PSBT');
                }

                const txid = await this.sendTxWithRetry(finalHex);
                
                // Notify seller
                this.socket.emit(`${this.myInfo.socketId}::swap`, {
                    eventName: 'COMPLETE',
                    socketId: this.myInfo.socketId,
                    data: { txid, tradeUUID: this.tradeUUID }
                });

                this.complete(txid);
            } else {
                // Seller is maker, needs final signature
                this.socket.emit(`${this.myInfo.socketId}::swap`, {
                    eventName: 'STEP2',
                    socketId: this.myInfo.socketId,
                    data: {
                        tradeUUID: this.tradeUUID,
                        psbtHex: signRes.data.psbtHex,
                        commitTxId: commitResult.txid,
                        commitUtxo: commitResult.utxo
                    }
                });
            }

            this.logTime('STEP2: Complete');
        } catch (err) {
            this.terminate(`Step2: ${err.message}`);
        }
    }

    // ==================== STEP 3: SELLER FINALIZES (if maker) ====================

    async handleStep2(data) {
        if (!this.isBuyer && this.isMaker) {
            await this.sellerStep3(data);
        }
    }

    async sellerStep3(data) {
        this.logTime('STEP3: Finalizing');
        try {
            const { psbtHex, commitTxId } = data;

            // 1. RBF check on buyer's commit
            if (commitTxId) {
                await this.checkRbf(commitTxId);
            }

            // 2. Sign the PSBT (maker signs last)
            const wif = await this.dumpprivkeyAsync(this.myInfo.keypair.address);
            const signRes = await signPsbtRawTx({ wif, network: this.network, psbtHex }, this.client);

            if (!signRes?.data?.finalHex) {
                throw new Error('Failed to finalize PSBT');
            }

            // 3. Broadcast
            const txid = await this.sendTxWithRetry(signRes.data.finalHex);

            // 4. Notify buyer
            this.socket.emit(`${this.myInfo.socketId}::swap`, {
                eventName: 'COMPLETE',
                socketId: this.myInfo.socketId,
                data: { txid, tradeUUID: this.tradeUUID }
            });

            this.complete(txid);
            this.logTime('STEP3: Complete');
        } catch (err) {
            this.terminate(`Step3: ${err.message}`);
        }
    }

    // ==================== HELPERS ====================

    getPubkeyOrder() {
        const props = this.tradeInfo.props || this.tradeInfo;
        const { propIdDesired, propIdForSale } = props;
        
        // LTC trades: buyer pubkey first
        if (propIdDesired === 0 || propIdForSale === 0) {
            return [this.tradeInfo.buyer.keypair.pubkey, this.tradeInfo.seller.keypair.pubkey];
        }
        // Token trades: seller pubkey first
        return [this.tradeInfo.seller.keypair.pubkey, this.tradeInfo.buyer.keypair.pubkey];
    }

    async getColumnInfo() {
        try {
            if (this.multySigChannelData?.address) {
                const channel = await this.getChannelAsync(this.multySigChannelData.address);
                if (channel?.participants) {
                    const iAmColumnA = channel.participants.A === this.myInfo.keypair.address;
                    return { iAmColumnA, participants: channel.participants };
                }
            }
        } catch (_) {}

        // Fallback to prediction
        let iAmColumnA = true;
        try {
            if (typeof WalletListener?.getColumn === 'function') {
                const col = await WalletListener.getColumn(this.myInfo.keypair.address, this.cpInfo.keypair.address);
                iAmColumnA = (col?.data ?? col) === 'A';
            }
        } catch (_) {}

        return { iAmColumnA };
    }

    async checkRbf(txid) {
        const tx = await this.getRawTransactionAsync(txid, true);
        if (!tx?.vin) throw new Error('Failed to get tx for RBF check');
        
        const isRbf = tx.vin.some(v => (v.sequence >>> 0) < 0xfffffffe);
        if (isRbf) throw new Error('RBF-enabled commit detected');
    }

    async buildAndSendCommit(columnInfo) {
        const props = this.tradeInfo.props || this.tradeInfo;
        const isFutures = 'contract_id' in props;
        
        let propertyId, amount;
        
        if (isFutures) {
            const margin = await this.ensureFuturesMargin(props);
            propertyId = margin.collateral;
            amount = margin.initMargin;
        } else {
            // SPOT: buyer commits what they're selling, seller commits what buyer wants
            if (this.isBuyer) {
                propertyId = props.propIdForSale;
                amount = props.amountForSale;
            } else {
                propertyId = props.propIdDesired;
                amount = props.amountDesired;
            }
        }

        const payload = Encode.encodeCommit({
            propertyId,
            amount,
            channelAddress: this.multySigChannelData.address
        });

        // Get UTXOs
        const utxos = await this.listUnspentAsync(0, 999999, [this.myInfo.keypair.address]);
        if (!utxos?.length) throw new Error('No UTXOs');
        
        const sorted = utxos.sort((a, b) => new BigNumber(b.amount).minus(a.amount).toNumber());
        const utxo = sorted[0];

        // Build tx
        const dust = 0.000056;
        const fee = 0.00003;
        const change = new BigNumber(utxo.amount).minus(dust).minus(fee).toNumber();
        if (change <= 0) throw new Error('Insufficient funds');

        const hexPayload = Buffer.from(payload, 'utf8').toString('hex');
        const rawTx = await this.createRawTransactionAsync(
            [{ txid: utxo.txid, vout: utxo.vout }],
            [
                { [this.multySigChannelData.address]: dust },
                { [this.myInfo.keypair.address]: change },
                { data: hexPayload }
            ]
        );

        // Sign and send
        const wif = await this.dumpprivkeyAsync(this.myInfo.keypair.address);
        const signRes = await this.signrawtransactionwithkeyAsync(rawTx, [wif]);
        const txid = await this.sendrawtransactionAsync(signRes.hex);

        // Decode to get UTXO
        const decoded = await this.decoderawtransactionAsync(signRes.hex);
        const vout = decoded.vout.find(o => o.scriptPubKey?.addresses?.[0] === this.multySigChannelData.address);

        return {
            txid,
            utxo: {
                txid,
                vout: vout.n,
                amount: vout.value,
                scriptPubKey: this.multySigChannelData.scriptPubKey,
                redeemScript: this.multySigChannelData.redeemScript
            }
        };
    }

    async buildTradePsbt(commitUtxo, expiryBlock, columnInfo) {
        const props = this.tradeInfo.props || this.tradeInfo;
        const isFutures = 'contract_id' in props;
        const { iAmColumnA } = columnInfo;

        // FIXED: columnAIsSeller logic
        // I am the SELLER in Step 1
        // If I'm column A and I'm seller, columnAIsSeller = 1
        // If I'm column B and I'm seller, columnAIsSeller = 0
        const columnAIsSeller = iAmColumnA ? 1 : 0;

        // columnAIsMaker
        const sellerIsMaker = props.sellerIsMaker ?? false;
        const sellerIsColumnA = iAmColumnA; // I'm seller in Step 1
        const columnAIsMaker = sellerIsColumnA ? (sellerIsMaker ? 1 : 0) : (sellerIsMaker ? 0 : 1);

        let payload;
        
        if (isFutures) {
            payload = Encode.encodeTradeContractChannel({
                contractId: props.contract_id,
                amount: props.amount,
                price: props.price,
                expiryBlock,
                columnAIsSeller,
                insurance: false,
                columnAIsMaker
            });

            const result = await buildFuturesTransaction({
                buyerKeyPair: this.tradeInfo.buyer.keypair,
                sellerKeyPair: this.tradeInfo.seller.keypair,
                commitUTXOs: [commitUtxo],
                payload
            }, this.client);

            return { psbtHex: result.psbtHex };
        } else {
            // SPOT
            const { propIdDesired, propIdForSale, amountDesired, amountForSale } = props;
            
            if (propIdDesired === 0 || propIdForSale === 0) {
                // LTC trade
                const tokenId = propIdForSale || propIdDesired;
                const tokenAmount = propIdForSale ? amountForSale : amountDesired;
                const satsExpected = propIdDesired === 0 ? amountDesired : amountForSale;

                payload = Encode.encodeTradeTokenForUTXO({
                    propertyId: tokenId,
                    amount: tokenAmount,
                    columnA: iAmColumnA,
                    satsExpected,
                    tokenOutput: 1,
                    payToAddress: 0
                });
            } else {
                // Token-to-token
                payload = Encode.encodeTradeTokensChannel({
                    propertyId1: propIdForSale,
                    propertyId2: propIdDesired,
                    amountOffered1: amountForSale,
                    amountDesired2: amountDesired,
                    expiryBlock,
                    columnAIsOfferer: iAmColumnA ? 1 : 0,
                    columnAIsMaker
                });
            }

            const result = await buildTokenTradeTransaction({
                buyerKeyPair: this.tradeInfo.buyer.keypair,
                sellerKeyPair: this.tradeInfo.seller.keypair,
                commitUTXOs: [commitUtxo],
                payload,
                amount: 0
            }, this.client);

            return { psbtHex: result.psbtHex };
        }
    }

    async ensureFuturesMargin(props) {
        if (this._futuresMargin) return this._futuresMargin;

        const { contract_id, price, amount } = props;
        const contractInfo = await WalletListener.getContractInfo(contract_id);
        if (!contractInfo) throw new Error(`No contract info for ${contract_id}`);

        const perContractMargin = await WalletListener.getInitialMargin(contract_id, price);
        if (!perContractMargin || perContractMargin <= 0) throw new Error('Invalid margin');

        this._futuresMargin = {
            collateral: contractInfo.collateralPropertyId,
            initMargin: perContractMargin * amount
        };

        return this._futuresMargin;
    }

    async sendTxWithRetry(rawTx, retries = 15, delay = 1200) {
        for (let i = 0; i < retries; i++) {
            try {
                const result = await this.sendrawtransactionAsync(rawTx);
                if (result && !result.error) return result;
            } catch (err) {
                if (i === retries - 1) throw err;
                await new Promise(r => setTimeout(r, delay));
            }
        }
        throw new Error('Failed to broadcast after retries');
    }
}

module.exports = StreamlinedSwapper;
