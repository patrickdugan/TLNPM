# NPM Streamlined Swap - 2-3 Round Trips

## Files

| File | Description |
|------|-------------|
| `streamlined-swapper.js` | Unified swapper class handling both buyer/seller roles |
| `orderbook-streamlined.js` | Updated orderbook session using streamlined swapper |

## Flow Overview

```
SELLER (Initiator)                    BUYER (Responder)
       │                                    │
       ├──── STEP 1 ───────────────────────►│
       │  • Create multisig                 │
       │  • Build + send commit tx          │
       │  • Build PSBT                      │
       │  • Sign if TAKER                   │
       │                                    │
       │                                    ├── STEP 2
       │                                    │  • Verify multisig
       │                                    │  • RBF check
       │                                    │  • Build + send commit
       │                                    │  • Sign PSBT
       │                                    │
       │  [If seller was TAKER]             │
       │◄──── COMPLETE ─────────────────────┤  • Finalize + broadcast
       │                                    │
       │  [If seller was MAKER]             │
       │◄──── STEP 2 ───────────────────────┤  • Return signed PSBT
       │                                    │
       ├──── STEP 3 ───────────────────────►│
       │  • RBF check                       │
       │  • Sign (maker last)               │
       │  • Finalize + broadcast            │
       │                                    │
       │◄──── COMPLETE ─────────────────────┤
```

## Key Fix: columnAIsSeller

The original bug in buyer.js line 503:

```javascript
// WRONG - isA means "am I column A", not "is A the seller"
columnAIsSeller: isA,
```

Fixed logic in streamlined-swapper.js:

```javascript
// I am the SELLER in Step 1
// If I'm column A and I'm seller -> columnAIsSeller = 1 (true)
// If I'm column B and I'm seller -> columnAIsSeller = 0 (false)
const columnAIsSeller = iAmColumnA ? 1 : 0;
```

## Usage

### Replace existing files:

```javascript
// In your main entry point
const OrderbookSession = require('./orderbook-streamlined.js');

// Usage remains the same
const session = new OrderbookSession(socket, myInfo, client, test);
```

### The swapper is used internally by OrderbookSession

When a `new-channel` event arrives, OrderbookSession:
1. Determines if we're buyer or seller
2. Creates a StreamlinedSwapper instance
3. Calls `swapper.onReady()` which returns a promise
4. Promise resolves with `{ data: { txid } }` or `{ error: 'reason' }`

## Maker/Taker Logic

```javascript
// From trade props
const sellerIsMaker = props.sellerIsMaker ?? false;

// In StreamlinedSwapper
get isMaker() {
    const sellerIsMaker = this.tradeInfo.props?.sellerIsMaker ?? false;
    // If I'm buyer: I'm maker if seller is NOT maker
    // If I'm seller: I'm maker if seller IS maker
    return this.isBuyer ? !sellerIsMaker : sellerIsMaker;
}
```

**Why it matters:**
- **Taker signs first** - commits to the trade, can't RBF
- **Maker signs last** - has final control before broadcast

## RPC Calls Per Trade

| Step | Seller (Initiator) | Buyer (Responder) |
|------|-------------------|-------------------|
| Multisig | addmultisigaddress, validateaddress | addmultisigaddress |
| Commit | listunspent, createrawtransaction, signrawtransactionwithkey, sendrawtransaction, decoderawtransaction | same |
| PSBT | buildFuturesTransaction/buildTokenTradeTransaction | - |
| Sign | dumpprivkey, signPsbt (if taker) | dumpprivkey, signPsbt |
| RBF Check | - | getrawtransaction |
| Finalize | signPsbt (if maker), sendrawtransaction | sendrawtransaction (if taker finishes) |

**Total: ~12-15 RPC calls** (down from ~20+ in 6-step flow)

## Error Handling

Swapper terminates trade on any error and notifies peer:

```javascript
terminate(reason) {
    this.socket.emit(`${this.myInfo.socketId}::swap`, {
        eventName: 'TERMINATE',
        socketId: this.myInfo.socketId,
        data: { reason, tradeUUID: this.tradeUUID }
    });
    this.cleanup();
    this.readyRes?.({ error: reason });
}
```

## Timeout

Default 90 second timeout per trade:

```javascript
setTimeout(() => this.terminate('Timeout'), 90000);
```

## Testing

To verify the fix, check logs for:

```
[BUYER] Column participants: A=<addr1>, B=<addr2>
[BUYER] My address: <myAddr>
BUYER: iAmColumnA=false, therefore columnAIsSeller=1
```

If you're column B and buying, `columnAIsSeller` should be `1` (A is the seller).
